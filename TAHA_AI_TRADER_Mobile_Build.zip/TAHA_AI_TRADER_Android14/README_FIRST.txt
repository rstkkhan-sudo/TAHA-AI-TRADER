TAHA AI TRADER — ANDROID 14 SOURCE PROJECT (v1)

IMPORTANT: This is an Android Studio source project, NOT a compiled APK yet.
I cannot truthfully call it an installable APK until it is built and tested on an Android build environment.

WHAT THIS PROTOTYPE DOES
- Android app with a local 4-digit app PIN (SHA-256 hash stored locally).
- Reads public BTC/USDT 15-minute Binance candle data; no Binance account or API key.
- Runs a simple SMA crossover + RSI paper-trading strategy.
- Simulates buys/sells only; no real orders, no deposits, no withdrawals.
- Stores virtual account values locally on the phone.

DEMO BALANCE
- Starter virtual balance is approximately 5,000 PKR converted at a placeholder rate of 0.00355 USDT per PKR (17.75 USDT).
- This conversion is only a simulation estimate and can be changed in MainActivity.java.
- Paper trading is not evidence of future profitability.

BUILD APK
1. On a Windows/Mac/Linux computer, install Android Studio.
2. Open this extracted folder in Android Studio.
3. Allow Gradle sync and install any requested Android SDK platform (compile SDK 35).
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK path. Transfer it to the Redmi phone and install it.
6. Only install APKs you built yourself or obtained from a trusted source. Do not disable Android security protections for unknown APKs.

LIMITATIONS / NEXT WORK
- This is a starter prototype, not a production-grade AI or financial product.
- It uses a transparent indicator strategy, not machine-learning AI.
- The app PIN is a basic local access barrier, not protection against a compromised/rooted phone.
- No encryption of trade history yet; no cloud sync; no real trading integration.
- The bot only runs while the app process remains active; Android battery optimization may stop background work.
- Test on demo mode first. Never add withdrawal permissions to any future exchange API key.

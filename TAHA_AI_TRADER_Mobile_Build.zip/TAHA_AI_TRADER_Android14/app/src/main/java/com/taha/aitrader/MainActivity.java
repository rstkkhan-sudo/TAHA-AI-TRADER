package com.taha.aitrader;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String PREF = "taha_paper";
    private static final String API = "https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=15m&limit=100";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private LinearLayout root;
    private TextView status, priceText, balanceText, pnlText, signalText, tradesText;
    private Button runButton;
    private boolean running = false;
    private double cash, qty, entry, startCash;
    private int tradeCount = 0;
    private String lastSignal = "WAITING";
    private final Runnable loop = new Runnable() {
        @Override public void run() {
            if (!running) return;
            worker.execute(() -> {
                try {
                    JSONArray candles = new JSONArray(download(API));
                    double[] closes = new double[candles.length() - 1];
                    for (int i = 0; i < closes.length; i++) closes[i] = Double.parseDouble(candles.getJSONArray(i).getString(4));
                    if (closes.length < 30) throw new Exception("Not enough candle data");
                    double price = closes[closes.length - 1];
                    double fast = sma(closes, 9), slow = sma(closes, 21);
                    double prevFast = sma(closes, 9, closes.length - 1), prevSlow = sma(closes, 21, closes.length - 1);
                    double rsi = rsi(closes, 14);
                    boolean up = prevFast <= prevSlow && fast > slow;
                    boolean down = prevFast >= prevSlow && fast < slow;
                    String note = "No trade signal";
                    if (qty > 0 && entry > 0) {
                        double change = price / entry - 1.0;
                        if (change <= -0.02 || change >= 0.03 || down) {
                            cash += qty * price * 0.999;
                            qty = 0; entry = 0; tradeCount++;
                            note = "PAPER SELL";
                            lastSignal = note;
                        }
                    } else if (up && rsi >= 45 && rsi <= 65) {
                        double spend = cash * 0.25;
                        qty = (spend * 0.999) / price;
                        cash -= spend; entry = price;
                        note = "PAPER BUY";
                        lastSignal = note;
                    }
                    saveState();
                    double equity = cash + qty * price;
                    final String p = String.format("BTC/USDT: %.2f", price);
                    final String b = String.format("Virtual equity: %.2f USDT", equity);
                    final String pl = String.format("Demo P/L: %+.2f USDT", equity - startCash);
                    final String sig = String.format("%s | SMA9 %.2f / SMA21 %.2f | RSI %.1f", note, fast, slow, rsi);
                    handler.post(() -> {
                        priceText.setText(p); balanceText.setText(b); pnlText.setText(pl);
                        signalText.setText("Signal: " + sig);
                        tradesText.setText("Closed paper trades: " + tradeCount + "   |   Last: " + lastSignal);
                        status.setText("Connected to public Binance market data");
                    });
                } catch (Exception e) {
                    handler.post(() -> status.setText("Market data unavailable. Check internet and retry."));
                }
            });
            handler.postDelayed(this, 60000);
        }
    };

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs = getSharedPreferences(PREF, MODE_PRIVATE);
        cash = Double.longBitsToDouble(prefs.getLong("cash", Double.doubleToLongBits(17.75)));
        startCash = Double.longBitsToDouble(prefs.getLong("start", Double.doubleToLongBits(17.75)));
        qty = Double.longBitsToDouble(prefs.getLong("qty", Double.doubleToLongBits(0)));
        entry = Double.longBitsToDouble(prefs.getLong("entry", Double.doubleToLongBits(0)));
        tradeCount = prefs.getInt("trades", 0);
        lastSignal = prefs.getString("last", "WAITING");
        if (prefs.getString("pin_hash", null) == null) showPinSetup(); else showPinEntry();
    }

    private void showPinSetup() {
        LinearLayout box = page();
        addTitle(box, "Set your 4-digit PIN");
        TextView info = text("Create a PIN to protect access to this app. Do not reuse your banking PIN.");
        box.addView(info);
        EditText pin = new EditText(this); pin.setHint("4-digit PIN"); pin.setInputType( android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        box.addView(pin);
        Button save = button("SAVE PIN"); box.addView(save);
        save.setOnClickListener(v -> {
            String s = pin.getText().toString();
            if (!s.matches("\\d{4}")) { pin.setError("Enter exactly 4 digits"); return; }
            prefs.edit().putString("pin_hash", hash(s)).apply();
            showDashboard();
        });
    }

    private void showPinEntry() {
        LinearLayout box = page();
        addTitle(box, "TAHA AI TRADER");
        box.addView(text("Enter your app PIN"));
        EditText pin = new EditText(this); pin.setHint("4-digit PIN"); pin.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        box.addView(pin);
        Button unlock = button("UNLOCK"); box.addView(unlock);
        TextView msg = text(""); box.addView(msg);
        unlock.setOnClickListener(v -> {
            if (hash(pin.getText().toString()).equals(prefs.getString("pin_hash", ""))) showDashboard();
            else msg.setText("Incorrect PIN. Try again.");
        });
    }

    private void showDashboard() {
        running = false; handler.removeCallbacks(loop);
        root = page();
        addTitle(root, "TAHA AI TRADER");
        TextView demo = text("DEMO / PAPER TRADING ONLY"); demo.setTextColor(Color.rgb(22,125,90)); root.addView(demo);
        priceText = text("BTC/USDT: waiting…"); root.addView(priceText);
        balanceText = text("Virtual equity: loading…"); root.addView(balanceText);
        pnlText = text("Demo P/L: loading…"); root.addView(pnlText);
        signalText = text("Signal: waiting for market data"); root.addView(signalText);
        tradesText = text("Closed paper trades: " + tradeCount); root.addView(tradesText);
        status = text("Bot stopped"); root.addView(status);
        runButton = button("START AUTO DEMO"); root.addView(runButton);
        Button reset = button("RESET VIRTUAL ACCOUNT"); root.addView(reset);
        TextView safety = text("Security: no exchange login, no API keys, no withdrawals, no real orders. Public market prices require internet.");
        safety.setTextSize(12); root.addView(safety);
        runButton.setOnClickListener(v -> {
            running = !running;
            runButton.setText(running ? "STOP AUTO DEMO" : "START AUTO DEMO");
            status.setText(running ? "Starting paper trader…" : "Bot stopped");
            if (running) { handler.removeCallbacks(loop); handler.post(loop); }
            else handler.removeCallbacks(loop);
        });
        reset.setOnClickListener(v -> new android.app.AlertDialog.Builder(this)
            .setTitle("Reset demo account?")
            .setMessage("This deletes the local virtual balance and trade count.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Reset", (d,w) -> {
                running = false; handler.removeCallbacks(loop);
                cash = 17.75; startCash = 17.75; qty = 0; entry = 0; tradeCount = 0; lastSignal = "RESET";
                saveState(); showDashboard();
            }).show());
    }

    private LinearLayout page() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(36, 42, 36, 30); l.setGravity(Gravity.TOP);
        l.setBackgroundColor(Color.rgb(245,247,250));
        setContentView(l); return l;
    }
    private void addTitle(LinearLayout l, String s) {
        TextView t = text(s); t.setTextSize(24); t.setTextColor(Color.rgb(16,27,43)); t.setPadding(0,0,0,24); l.addView(t);
    }
    private TextView text(String s) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.rgb(35,48,65)); t.setTextSize(16); t.setPadding(0,10,0,10); return t;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); return b;
    }
    private String download(String address) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(address).openConnection();
        c.setConnectTimeout(10000); c.setReadTimeout(10000); c.setRequestMethod("GET");
        try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()))) {
            StringBuilder out = new StringBuilder(); String line;
            while ((line = r.readLine()) != null) out.append(line);
            return out.toString();
        } finally { c.disconnect(); }
    }
    private double sma(double[] a, int n) { return sma(a, n, a.length); }
    private double sma(double[] a, int n, int end) {
        double sum = 0; for (int i = end - n; i < end; i++) sum += a[i]; return sum / n;
    }
    private double rsi(double[] a, int n) {
        double gain = 0, loss = 0;
        for (int i = a.length - n; i < a.length; i++) {
            double d = a[i] - a[i-1]; if (d > 0) gain += d; else loss -= d;
        }
        if (loss == 0) return 100;
        double rs = (gain / n) / (loss / n); return 100 - (100 / (1 + rs));
    }
    private void saveState() {
        prefs.edit()
            .putLong("cash", Double.doubleToLongBits(cash))
            .putLong("start", Double.doubleToLongBits(startCash))
            .putLong("qty", Double.doubleToLongBits(qty))
            .putLong("entry", Double.doubleToLongBits(entry))
            .putInt("trades", tradeCount).putString("last", lastSignal).apply();
    }
    private String hash(String s) {
        try {
            byte[] b = MessageDigest.getInstance("SHA-256").digest(s.getBytes("UTF-8"));
            StringBuilder out = new StringBuilder(); for (byte x : b) out.append(String.format("%02x", x));
            return out.toString();
        } catch (Exception e) { return ""; }
    }
    @Override protected void onDestroy() {
        running = false; handler.removeCallbacks(loop); worker.shutdownNow(); super.onDestroy();
    }
}
